public class brain {

    public static void main(String[] args) {
        //Objects
        controlador newControlador = new controlador();

        //Methods
        newControlador.deployMenu();
    }
}
